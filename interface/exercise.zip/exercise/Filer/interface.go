package main

import (
	"fmt"
	"github.com/jinzhu/gorm"
)

type Filer interface {
	Create(tx *gorm.DB) (uint32, error)
}

func (doc *DocModel) Create(db *gorm.DB) (uint32, error) {
	tx := db.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	if err := tx.Create(doc).Error; err != nil {
		tx.Rollback()
		return 0, err
	}

	isFatherProject := false
	fatherId := doc.FatherId
	if doc.FatherId == 0 {
		isFatherProject = true
		fatherId = doc.ProjectID
	}

	if err := doc.AddChildren(tx, isFatherProject, fatherId); err != nil {
		tx.Rollback()
		return 0, err
	}

	return doc.ID, tx.Commit().Error
}

func (file *FileModel) Create(db *gorm.DB) (uint32, error) {
	tx := db.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	if err := tx.Create(file).Error; err != nil {
		tx.Rollback()
		return 0, err
	}

	isFatherProject := false
	fatherId := file.FatherId
	if file.FatherId == 0 {
		isFatherProject = true
		fatherId = file.ProjectID
	}

	if err := file.AddChildren(tx, isFatherProject, fatherId); err != nil {
		tx.Rollback()
		return 0, err
	}

	return file.ID, tx.Commit().Error
}

func (doc *DocModel) AddChildren(tx *gorm.DB, isFatherProject bool, fatherId uint32) error {
	id := doc.ID

	item := GetFolder(fatherId)

	newChildren, err := addChildren(item.Children, id)
	if err != nil {
		return err
	}

	item.Children = newChildren

	return tx.Save(item).Error
}

func (file *FileModel) AddChildren(tx *gorm.DB, isFatherProject bool, fatherId uint32) error {
	id := file.ID

	item := GetFolder(fatherId)

	newChildren, err := addChildren(item.Children, id)
	if err != nil {
		return err
	}

	item.Children = newChildren

	return tx.Save(item).Error
}

func Create(db *gorm.DB, f Filer) (uint32, error) {
	return f.Create(db)
}

func main() {
	var Type int
	fmt.Println("请输入要创建的类型,1---doc,2---file")
	fmt.Scanf("%d", &Type)
	var doc *DocModel
	var file *FileModel
	var document Filer
	switch Type {
	case 1:
		document = doc
		break
	case 2:
		document = file
		break
	}
	var DB *gorm.DB
	Create(DB, document)

}
